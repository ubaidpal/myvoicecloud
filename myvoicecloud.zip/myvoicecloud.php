<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://myvoicecloud.com
 * @since             1.0.0
 * @package           Myvoicecloud
 *
 * @wordpress-plugin
 * Plugin Name:       MyVoiceCloud
 * Plugin URI:        https://myvoicecloud.com
 * Description:       This is a short description of what the plugin does. It's displayed in the WordPress admin area.
 * Version:           1.0.0
 * Author:            Andreas Lengyel
 * Author URI:        https://myvoicecloud.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       myvoicecloud
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}
// plugin pth define at constant
if(!defined("VOICE_CLOUD_PLUGIN_DIR"))
    define("VOICE_CLOUD_PLUGIN_DIR", plugin_dir_path(__FILE__));
if(!defined("VOICE_CLOUD_PLUGIN_URL"))
    define("VOICE_CLOUD_PLUGIN_URL", plugins_url(). "/myvoicecloud");
//echo VOICE_CLOUD_PLUGIN_DIR."<br>".VOICE_CLOUD_PLUGIN_URL;
/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'MYVOICECLOUD_VERSION', '1.0.0' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-myvoicecloud-activator.php
 */
function activate_myvoicecloud() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-myvoicecloud-activator.php';
    $tables = tables_generator(); // called table instance
	$activator = new Myvoicecloud_Activator($tables);
    $activator->activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-myvoicecloud-deactivator.php
 */
function deactivate_myvoicecloud() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-myvoicecloud-deactivator.php';
    $tables = tables_generator(); // called table instance
    $deactivator = new Myvoicecloud_Deactivator($tables);
    $deactivator->deactivate();
}
/**
 * The code that use for declare tables at center.
 * This action is documented in includes/class-myvoicecloud-tables.php
 */
function tables_generator(){
    require_once plugin_dir_path( __FILE__ ) . 'includes/class-myvoicecloud-tables.php';
    $tables = new Myvoicecloud_Tables();
    return $tables;
}

register_activation_hook( __FILE__, 'activate_myvoicecloud' );
register_deactivation_hook( __FILE__, 'deactivate_myvoicecloud' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-myvoicecloud.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_myvoicecloud() {

	$plugin = new Myvoicecloud();
	$plugin->run();

}
run_myvoicecloud();
