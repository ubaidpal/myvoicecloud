<?php wp_enqueue_media(); ?>

<div class="container">
<div class="panel panel-primary">
    <div class="panel-heading"><h3>Add Audio</h3></div>
    <div class="panel-body">
        <form class="form-horizontal" action="javascript:void(0)" id="frmAddProduct">
            <div class="form-group">
                <label class="control-label col-sm-4" for="text">Title</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" id="title" name="title" required="" placeholder="Enter Title">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-6" for="image">Upload Thumbnail:</label>
                <div class="col-sm-6">
                    <button class="btn btn-info" type="button" id="media-upload">Upload Image</button>
                    <span><img src="" id="media-image" style="height: 100px;width:100px"/></span>
                    <input type="hidden" id="image-url" name="image_url"/>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-4" for="text">Transcription</label>
                <div class="col-sm-8">
                    <textarea id="tiny" class="form-control" name="transcription"  required=""></textarea>
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-sm-4" for="text">Scrolling Speed (15 is good start, test out to increase or decrease to your satisfaction)</label>
                <div class="col-sm-8">
                    <input required="" type="text" class="form-control" name="speed" placeholder="Scrolling Speed (15 is good start, test out to increase or decrease to your satisfaction)" value="15">
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-sm-4" for="text">Options (Could be an array or parameter you wanna send for this specific product)</label>
                <div class="col-sm-8">
                    <input required="" type="text" class="form-control" name="options" placeholder="Options (Could be an array or parameter you wanna send for this specific product)" value="null">
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-sm-4" for="text">Category Tag (Has to be unique, think of it as a Product ID or SKU)</label>
                <div class="col-sm-8">
                    <input required="" type="text" class="form-control" name="category_tag" placeholder="Category Tag (Has to be unique, think of it as a Product ID or SKU)" value="">
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-sm-4" for="image">Upload Thumbnail:</label>
                <div class="col-sm-8">
                    <button class="btn btn-info" type="button" id="audio-upload">Upload Audio</button>
                    <span  id="audio-image" style="height: 100px;width:100px"</span>
                    <input type="hidden" id="audio-url" name="audio_url"/>
                </div>
            </div>
            <div class="form-group">

            <label class="switch">
                <input type="checkbox" name="">
                <span class="slider round"></span>

            </label>
                <label class="control-label col-sm-8" for="image">  Visibility (Show or hide this product in your listing)</label>
            </div>


            <div class="form-group">

                <label class="control-label col-sm-4" for="name">Export Format (What you want your users to download)</label>
                <select class="form-control col-sm-8" name="export_format" aria-hidden="true">
                    <option value="wav" selected="&quot;selected&quot;">WAV</option>
                    <option value="m4a">M4A</option>
                    <option value="mp3">MP3</option>
                </select>

            </div>

            <div class="form-group"> 
                <div class="col-sm-offset-2 col-sm-10">
                    <button type="submit" class="btn btn-success">Submit</button>
                </div>
            </div>
        </form>
    </div>
</div>
</div>
