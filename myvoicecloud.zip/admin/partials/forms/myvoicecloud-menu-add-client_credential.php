<?php wp_enqueue_media(); ?>

<div class="container">
<div class="panel panel-primary">
    <div class="panel-heading"><h3>Add Credential</h3></div>
    <div class="panel-body">
        <form class="form-horizontal" action="javascript:void(0)" id="frmAddClientCredential">
            <div class="form-group">
                <label class="control-label col-sm-4" for="text">Name</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" id="name" name="name" required="" placeholder="Enter Name">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-4" for="text">Sub Domain</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" id="subdomain" name="subdomain" required="" placeholder="Enter Name">
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-sm-6" for="image">Upload Image:</label>
                <div class="col-sm-6">
                    <button class="btn btn-info" type="button" id="client-image-upload">Upload Image</button>
                    <span><img src="" id="client-media-image" style="height: 100px;width:100px"/></span>
                    <input type="hidden" id="client-image-url" name="image_url"/>
                </div>
            </div>


            </div>

            <div class="form-group"> 
                <div class="col-sm-offset-2 col-sm-10">
                    <button type="submit" class="btn btn-success">Submit</button>
                </div>
            </div>
        </form>
    </div>
</div>

