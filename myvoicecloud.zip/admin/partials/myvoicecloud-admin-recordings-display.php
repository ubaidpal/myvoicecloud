
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery.marquee@1.5.0/jquery.marquee.min.js" type="text/javascript"></script>
<!--    <script src="https://cdnjs.cloudflare.com/ajax/libs/p5.js/1.3.1/p5.min.js" type="text/javascript"></script>-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<body class="js-loading ">
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KW524DF"
                  height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<div class="preloader">
    <div class="loader">
        <span class="loader__indicator"></span>
        <div class="loader__label">MyVoiceCloud.com Get ready to manifest...</div>
    </div>
</div>


<div class="navbar navbar-light navbar-expand-lg">

</div>



<div class="page-wrap">


    <div class="page-content">

        <div class="container-fluid">
           <!-- content-->
            <script>
                var bgimage = '<?php echo @$products[0]['background']; ?>';
                jQuery(document).ready(function ($) {
                    // Read documentation on MyVoiceCloud at https://MyVoiceCloud.com/api/

                    $('.btn-save').hide(); //We're hiding the save button to show it once recording has been stopped
                    $('.btn-pause').attr('disabled','disabled'); //And disabling the paus and stop button to enable them once recording has started
                    $('.btn-stop').attr('disabled','disabled');

                    MyVoiceCloud.on('rendered', function (e) {
                        console.log('MyVoiceCloud has rendered and events are working!', e);
                    });

                    var recorder = MyVoiceCloud.init({
                        targetSelectorId: '#audio-player', //you can put your own id here for your player when nessecary

                        clientId: 27, //Your MyVoiceCloud clientId
                        apiUrl: 'https://api.myvoicecloud.com',
                        hideFrontend: true, //set to false to show the player, set to true to hide the player
                        clientEntity: <?php echo (!empty(@$products[0]['client_id'])) ? @$products[0]['client_id'] : 17; ?>, // This is the User identifier
                    });
                    var mq = $('.marquee').marquee(); // Loading the marquee element into a variable
                    recorder.clientAPI.socket.on('connected', function (e) {
                        console.log('Socket connected', e); // The socket for recording has been connected

                        recorder.clientAPI.socket.on('file_recorded', function (e) {
                            console.log('The recorded file has been processed and is ready to be played', e);
                        });
                    });

                    MyVoiceCloud.onRecording(function (e) {
                        console.log('Recording is in the making: ', e);

                        var minutes = Math.floor(e.recordingTime / 60);
                        var seconds = "0" + (parseInt(e.recordingTime - minutes * 60));
                        seconds = seconds.substr(-2);

                        $('.timing').html("Elapsed time: " + minutes + ":" + seconds); // Showing and updating the duration time of recording

                        $('.levels').html(e.levels[0]); // Showing and updating the volume bar

                        $('.ar-sound-now').css('background-color', '#52a727bd');
                        if (e.levels[0] >= 17) {
                            $('.ar-sound-now').css('background-color', '#ffe500bd');
                        }
                        if (e.levels[0] >= 24) {
                            $('.ar-sound-now').css('background-color', '#ed0909d0');
                        }
                        $('.ar-sound-now').css('width', (e.levels[0] * 3) + '%'); // Showing and updating the volume level

                        $('.ar-sound-now').attr('aria-valuenow', e.levels[0] * 3);
                    });



                    //Lets fetch info about the product using getProduct call
                 recorder.clientAPI.getProduct('<?php echo (!empty(@$products[0]['category_tag'])) ? $products[0]['category_tag'] : 'twinkle'; ?>',function(response){
                      //  recorder.clientAPI.getProduct('twinkle',function(response){
                        console.log('Response from getProduct, this is your smorgasbord of stuff to choose from: ', response);
                        $('.marquee').marquee('destroy'); //Resetting existing marquee element
                        //Load new content using Ajax and update the marquee element
                      mq = $('.marquee').html(response.data.transcription)
                    //    mq = $('.marquee').html('<?php echo (!empty(@$products[0]['transcription'])) ? $products[0]['transcription'] : '<p>Twinkle Twinkle Little Star</p>'; ?>')
                            //Apply stuff to marquee again
                           .marquee({ speed: response.data.speed, }); // Setting scroll speed from product settings in MyVoiceCloud admin
                         //   .marquee({ speed: '<?php echo (!empty(@$products[0]['speed'])) ? $products[0]['speed'] : 15; ?>', }); // Setting scroll speed from product settings in MyVoiceCloud admin
                        mq.marquee('pause'); // Make sure marquee is ready to scroll

                       recording_name = $('.recording_name').text(response.data.title); // Lets put the original title into the span element
                     //   recording_name = $('.recording_name').text('<?php echo (!empty(@$products[0]['title'])) ? $products[0]['title'] : 15; ?>'); // Lets put the original title into the span element

                     //   bgImage = $('.bgImage').attr('src', '/storage/'+response.data.background); // Set product image element src from getProduct response
                        bgImage = $('.bgImage').attr('src', bgimage); // Set product image element src from getProduct response

                        //Test if browser supports ogg or if we have to use mp3
                        function supportsAudioType(type) {
                            let audio;

                            let formats = {
                                ogg: 'audio/ogg',
                                mp3: 'audio/mpeg'
                            };

                            if(!audio) {
                                audio = document.createElement('audio')
                            }

                            return audio.canPlayType(formats[type] || type);
                        }

                        if(supportsAudioType('ogg') != "") {
                            // Set backtrack element src and type to support ogg
                            backtrack = $('#backtrack').attr('src', response.data.backtrack_ogg);
                            backtrack_type = $('#backtrack').attr('type', 'audio/ogg');
                        }
                        else {
                            // Set backtrack element src and type to support mp3
                            backtrack_mp3 = $('#backtrack').attr('src', response.data.backtrack);
                            backtrack_type = $('#backtrack').attr('type', 'audio/mpeg');
                        }
                    }); // getProduct ends here

                    // 1. Listen for changes of the contenteditable element
                    var content = document.querySelector('[contenteditable]');
                    content.addEventListener('input', function(event) {
                        // 2. Retrieve the text from inside the element and update recording_name so we have the latest edit on save
                        recording_name = content.innerHTML;
                    });

                    // Lets make sure we ignore the enter key as it adds a nbsp to the input
                    $('[contenteditable]').on('keypress', function(e) {
                        if(!/[A-Za-z0-9\s]/.test(e.key)) {
                            e.preventDefault();
                        }
                        if (e.which == 13) {
                            $('[contenteditable]').trigger('blur'); // Blur focus from the input field, looks neat
                        };
                        //ignores enter key
                        return e.which != 13;
                    });

                    //Variables for pause timeout function
                    var saveTimeout = null;
                    var pauseInterval = null;

                    $('.btn-start').click(function () {
                        //Let's enable the paus and stop button as recording has started
                        $('.btn-pause').removeAttr('disabled');
                        $('.btn-stop').removeAttr('disabled');
                        alert("Hey it's Hafiz Ali this project is run at my local");
                        MyVoiceCloud.startRecording(); // Starts recording process


                        if(pauseInterval){
                            clearInterval(pauseInterval);
                            pauseInterval = null;
                            $('.btn-pause').text($('.btn-pause').data('caption'));
                        }else {
                            clearTimeout(saveTimeout);
                        }
                    });

                    $('.btn-pause').click(function(){
                        MyVoiceCloud.pauseRecording(); // Pause recording on pause button click
                        var caption = $('.btn-pause').data('caption');
                        if(!pauseInterval) {
                            $('#transcript').attr('scrollamount',0); // Stop the scroll of the marquee element
                            //  var secondsCount = 250; // Set timer to 5 minutes
                            var secondsCount = 300; // Set timer to 5 minutes
                            pauseInterval = setInterval(function () {
                                if (secondsCount < 0) {

                                    clearInterval(pauseInterval);
                                    pauseInterval = null;

                                }else{
                                    // Countdown 5 minutes in the button caption
                                    $('.btn-pause').text(caption + '('+secondsCount+'s.)');
                                    secondsCount--;
                                }
                            }, 1000);
                        }
                    });

                    $('.btn-stop').click(function(){
                        // Disable the buttons while processing the recorded file
                        $('.btn-start').attr('disabled','disabled');
                        $('.btn-start').hide();
                        $('.btn-pause').attr('disabled','disabled');
                        $('.btn-pause').hide();
                        $('.btn-stop').attr('disabled','disabled');
                        $('.btn-stop').hide();
                        $('.btn-save').attr('disabled','disabled');
                        $('.btn-save').show(); // Show save button
                        MyVoiceCloud.stopRecording({title: $('.recording_name').html(), tags: 'product_{{@$product->category_tag}}'}); // Stops current recording, sets the title and product to save as
                    });

                    MyVoiceCloud.on('record-started',function(){ // Recording has started
                        $("#backtrack").get(0).play();; // Start the backtrack audio
                        mq.marquee('resume'); // Start scrolling the text
                    });

                    MyVoiceCloud.on('file_recorded', function (data) { // This event is called when server sends response after client recording has been processed. Recording has been transfered, file is ready to play, update caption, enable save button to take user back to list of recordings
                        $('.btn-save').text('GO TO LIST');
                        $('.btn-save').removeAttr('disabled');
                    });

                    MyVoiceCloud.on('record-stopped',function(){
                        mq.marquee('pause'); // Pause text from scrolling
                        document.getElementById('backtrack').pause(); // Pause backtrack audio from playing
                    });

                    MyVoiceCloud.on('export-is-started',function(){
                        // This event is called when server sends response after client recording started to export into targeted file format (e.g. from wav to m4a or mp3)
                    });
                });
            </script>
            <div class="container">
                <div class="row">
                    <div class="col-sm-9">
                        <div class="row">
                            <div class="col-md-1" style="display: flex; align-items: center;">
                                <image class="bgImage" src="" style="width: 75px; border-radius: 50px;">
                            </div>
                            <div class="col-md-11" style="display: flex; align-items: center;">
                                <h1 class="content-heading" style="text-transform: uppercase; margin-bottom: 0px !important; margin-top: 0px !important; position: relative; left: 10px !important;"><!--{{@$product->title}}--></h1>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <p>Your new track will be saved as: "<span contenteditable="true" class="recording_name"></span>"<i class="fa fa-pencil" aria-hidden="false"> (Click at the name the set your own)</i></p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <p class="">Lets record your own voice for the track 'Dynamic Title'! This whole new audio experience will be created once you've recorded and saved your session.</p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-8 col-sm-12">
                                <div class="marquee"  data-duration='5000'  data-direction="up" >

                                </div>

                                <div>Levels: <span class="levels"></span></div>
                                <div class="ar-sound-level">
                                    <div class="ar-sound-now"></div>
                                </div>
                                <div>Timing: <span class="timing"></span></div>
                            </div>
                            <div class="col-md-4 col-sm-12">
                                <p>INSTRUCTIONS<br/>
                                    Make sure you don't distort your recording by talking to closely or to loudly into your microphone.
                                    <br/>
                                    Hit the record button and start read the
                                    transcript as it scrolls up.
                                </p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-3">
                                <audio
                                        class="backtrack"
                                        id="backtrack"
                                        src=""
                                        type=""
                                        preload="auto"
                                >
                                </audio>
                                <button type="button" class="btn btn-danger btn-lg btn-block btn-start" onclick="document.getElementById('backtrack').load();">RECORD</button>
                            </div>
                            <div class="col-md-3">
                                <button type="button" id="btn-pause" class="btn btn-secondary btn-lg btn-block btn-pause" data-caption="PAUSE" onclick="">PAUSE
                                </button>
                            </div>
                            <div class="col-md-3">
                                <button type="button" class="btn btn-secondary btn-lg btn-block btn-stop" onclick="">STOP
                                </button>
                            </div>
                            <div class="col-md-3">
                                <a  class="btn btn-dark btn-lg btn-block btn-save" href="admin.php?page=submenu-recordings">
                                    <span class="spinner-border" style="padding: 0px !important; margin-right: 10px; width: 2rem; height: 2rem;" role="status" aria-hidden="true"></span>Wait While Saving...
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <style>
                .marquee {
                    overflow: hidden;
                    height:300px;
                }
                @media only screen and (max-width: 480px) {
                    .marquee {
                        height: 150px;
                    }
                }

                [type=button]:not(:disabled), [type=reset]:not(:disabled), [type=submit]:not(:disabled), button:not(:disabled) {
                    cursor: pointer;
                }
                [type=button], [type=reset], [type=submit], button {
                    -webkit-appearance: button;
                }
            </style>
           <!-- End content-->

        </div>

    </div>
</div>





