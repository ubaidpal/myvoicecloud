
<div class="panel panel-primary">
    <div class="panel-heading"> <a href="admin.php?page=submenu-add-products" class="btn btn-primary"  >Add Product</a></div>
    <div class="panel-body">
        <div class="panel-heading"><h3>Products</h3></div>
        <table id="example_table" class="table table-responsive table-striped table-bordered  nowrap"   style="width:100%;overflow-x:auto;">
            <thead>
                <tr>
                    <th>Created At</th>
                    <th>Title </th>
                    <th>ProductImage Transcription Scrolling Speed (15 is good start, test out to increase or decrease to your satisfaction) </th>
                    <th>Options (Could be an array or parameter you wanna send for this specific product) </th>
                    <th> Category Tag (Has to be unique, think of it as a Product ID or SKU)  </th>
                    <th>Background Audio (Only Wav Format, minimum 44.1khz, 16 bit, preferably 48khz, 24 bit)  </th>
                    <th>Visibility (Show or hide this product in your listing)</th>
                    <th> Client Id</th>
                    <th>Export Format (What you want your users to download)</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody id="boiler-table-playlist">

                <?php
                  ob_start(); // start the buffer
                   // include file
                   
                   include_once VOICE_CLOUD_PLUGIN_DIR."/admin/partials/forms/tmpl/plugin-tmpl-product-list.php";
                   // read the buffer
                   $template = ob_get_contents();
                   // close the buffer
                   ob_end_clean();
                   
                   echo $template;
                ?>
            </tbody>
        </table>
    </div>
</div>


<!-- Modal audio -->
<?php wp_enqueue_media(); ?>
<div id="boiler-edit-modal" class="modal fade bd-example-modal-xlg" role="dialog" style="overflow-y: auto">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Update</h4>
      </div>
      <div class="modal-body">
          <div class="container">
              <div class="panel panel-primary">
                  <div class="panel-heading"><h3>Update</h3></div>
                  <div class="panel-body">
                      <form class="form-horizontal" action="javascript:void(0)" id="frmUpdateProduct">
                          <div class="form-group">
                              <label class="control-label col-sm-4" for="text">Title</label>
                              <div class="col-sm-8">
                                  <input type="text" class="form-control" id="title" name="title" required="" placeholder="Enter Title">
                                  <input type="hidden" id="p_id" value="" name="p_id"/>
                              </div>
                          </div>
                          <div class="form-group">
                              <label class="control-label col-sm-6" for="image">Upload Thumbnail:</label>
                              <div class="col-sm-6">
                                  <button class="btn btn-info" type="button" id="media-upload">Upload Image</button>
                                  <span><img src="" id="media-image" style="height: 100px;width:100px"/></span>
                                  <input type="hidden" id="image-url" name="image_url"/>
                              </div>
                          </div>
                          <div class="form-group">
                              <label class="control-label col-sm-4" for="text">Transcription</label>
                              <div class="col-sm-8">
                                  <textarea id="tiny" class="form-control" name="transcription"  required=""></textarea>
                              </div>
                          </div>

                          <div class="form-group">
                              <label class="control-label col-sm-4" for="text">Scrolling Speed (15 is good start, test out to increase or decrease to your satisfaction)</label>
                              <div class="col-sm-8">
                                  <input required="" id="speed" type="text" class="form-control" name="speed" placeholder="Scrolling Speed (15 is good start, test out to increase or decrease to your satisfaction)" value="15">
                              </div>
                          </div>

                          <div class="form-group">
                              <label class="control-label col-sm-4" for="text">Options (Could be an array or parameter you wanna send for this specific product)</label>
                              <div class="col-sm-8">
                                  <input required="" type="text" id="options" class="form-control" name="options" placeholder="Options (Could be an array or parameter you wanna send for this specific product)" value="null">
                              </div>
                          </div>

                          <div class="form-group">
                              <label class="control-label col-sm-4" for="text">Category Tag (Has to be unique, think of it as a Product ID or SKU)</label>
                              <div class="col-sm-8">
                                  <input required="" type="text" id="category_tag" class="form-control" name="category_tag" placeholder="Category Tag (Has to be unique, think of it as a Product ID or SKU)" value="">
                              </div>
                          </div>

                          <div class="form-group">
                              <label class="control-label col-sm-4" for="image">Upload Thumbnail:</label>
                              <div class="col-sm-8">
                                  <button class="btn btn-info" type="button" id="audio-upload">Upload Audio</button>
                                  <span  id="audio-url" style="height: 100px;width:100px"</span>
                                  <input type="hidden" id="audio_url" name="audio_url"/>
                              </div>
                          </div>
                          <div class="form-group">

                              <label class="switch">
                                  <input type="checkbox" id="active" name="active">
                                  <span class="slider round"></span>

                              </label>
                              <label class="control-label col-sm-8" for="image">  Visibility (Show or hide this product in your listing)</label>
                          </div>


                          <div class="form-group">

                              <label class="control-label col-sm-4" for="name">Export Format (What you want your users to download)</label>
                              <select class="form-control col-sm-8" name="export_format" id="export_format" aria-hidden="true">
                                  <option value="wav" >WAV</option>
                                  <option value="m4a">M4A</option>
                                  <option value="mp3">MP3</option>
                              </select>

                          </div>

                          <div class="form-group">
                              <div class="col-sm-offset-2 col-sm-10">
                                  <button type="submit" class="btn btn-success">Submit</button>
                              </div>
                          </div>
                      </form>
                  </div>
              </div>
          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>




