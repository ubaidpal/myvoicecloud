<?php

/**
 * Fired during plugin activation
 *
 * @link       https://myvoicecloud.com
 * @since      1.0.0
 *
 * @package    Myvoicecloud
 * @subpackage Myvoicecloud/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Myvoicecloud
 * @subpackage Myvoicecloud/includes
 * @author     Andreas Lengyel <support@myvoicecloud.com>
 */
class Myvoicecloud_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public  $table;
    public function __construct($table_var) {
        $this->table = $table_var;
	}
	public function activate() {

	  //flush_rewrite_rules();
        // when plugin activate create these tables
        globaL $wpdb;
      /*  $query = $wpdb->get_var("SELECT count(*) FROM information_schema.TABLES WHERE (TABLE_SCHEMA = 'wp_audio_categories') AND (TABLE_NAME = 'wp_audio_products') AND (TABLE_NAME = 'wp_audio_clients') AND (TABLE_NAME = 'wp_audio_client_plans')");*/

        $query = $wpdb->get_var("SHOW CREATE TABLE ".$this->table->wp_audio_categories());
        require_once ABSPATH. '/wp-admin/includes/upgrade.php';

        if(empty($query))
        {


            $sqlPath = 'CREATE TABLE '.$this->table->wp_audio_categories().' (
                         `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
                         `parent_id` int(10) unsigned DEFAULT NULL,
                         `order` int(11) NOT NULL DEFAULT 1,
                         `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
                         `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
                         `created_at` timestamp NULL DEFAULT NULL,
                         `updated_at` timestamp NULL DEFAULT NULL,
                         PRIMARY KEY (`id`)
                        ) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
            dbDelta($sqlPath);
            $sqlPath = "CREATE TABLE " . $this->table->wp_audio_products() . " (
                         `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                         `created_at` timestamp NULL DEFAULT NULL,
                         `updated_at` timestamp NULL DEFAULT NULL,
                         `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
                         `audio` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                         `background` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                         `transcription` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                         `speed` int(11) NOT NULL,
                         `options` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Special options',
                         `category_tag` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
                         `client_id` int(11) NOT NULL,
                         `export_format` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'wav',
                         PRIMARY KEY (`id`)
                        ) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

            dbDelta($sqlPath);
            $sqlPath = "CREATE TABLE  ".$this->table->wp_audio_clients()." (
                               `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                               `subdomain` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
                               `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
                               `created_at` timestamp NULL DEFAULT NULL,
                               `updated_at` timestamp NULL DEFAULT NULL,
                               `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
                               PRIMARY KEY (`id`)
                              ) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
            dbDelta($sqlPath);
            $sqlPath = "CREATE TABLE ".$this->table->wp_audio_client_plans()." (
                               `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                               `client_id` int(11) NOT NULL,
                               `time_end` int(11) NOT NULL COMMENT 'End of subscription',
                               `isActive` int(11) NOT NULL DEFAULT 1 COMMENT 'Did subscription is active',
                               `plan_sku` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
                               `created_at` timestamp NULL DEFAULT NULL,
                               `updated_at` timestamp NULL DEFAULT NULL,
                               PRIMARY KEY (`id`)
                              ) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";



            dbDelta($sqlPath);
        }
	}

}
