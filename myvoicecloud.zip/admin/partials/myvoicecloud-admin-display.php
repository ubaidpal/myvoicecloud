
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>


<script>
    $(document).ready(function () {
        $('#myModal').appendTo("body");

        MyVoiceCloud.on('rendered',function (e) {
            console.log(e);
            console.log('events are working!');
        });

        var recorder = MyVoiceCloud.init({
            targetSelectorId: '#audio-player', //you can put your own id here for your player when nessecary
            clientId: 27,
            apiUrl: 'https://api.myvoicecloud.com',
            hideFrontend: false,
            clientEntity: 17,
            hideRecorder: true,
        });

        //  console.log(recorder.clientAPI);

        recorder.clientAPI.getPlayList(function(response){
            response.data = response.data.reverse();
            for(var i in response.data){
                var item = response.data[i];
                var newItm = $('#player_donor').clone(true);
                newItm.find('.title').html(item.name_of_file);
                newItm.find('.tags').html(item.tags.replace('_',' '));
                newItm.find('audio source').attr('src','https://api.myvoicecloud.com/storage/'+item.path);
                //newItm.find('audio source').attr('src','https://api.myvoicecloud.com/storage/'+item.additionals);
                newItm.find('.created_at').html('Created '+item.created_at);
                newItm.find('.remove').data('id',item.id);
                newItm.addClass('recording_'+item.id);
                if(i>0){
                    newItm.removeClass('recording_'+response.data[0].id);
                };
                newItm.find('.remove').click(function(){
                    $('.delete-modal').data('id',$(this).data('id'));
                });
                $('.records').append(newItm);
            };
        });
        $('.delete-modal').click(function(e){
            var dataID = $(this).data('id');
            recorder.clientAPI.deleteFile($(this).data('id'),function(ret) {
                $('.recording_'+dataID).remove();
            },function (e) {
                console.log(e);
            });
        });
    });
</script>
<h2 class="content-heading">Recordings</h2>
<div class="content-description">List of My Recordings</div>
<hr/>
<div>
    <div style="display: none;">
        <div class="" id="player_donor" data-id="" style="padding: 20px;">
            <div>
                <h3 class="title"></h3>
            </div>
            <div>
                <h5>
                    <span hidden class="tags"></span>
                </h5>
                <span class="created_at"></span>
            </div>
            <div>
                <audio controls>
                    <source src="" type="audio/wav">
                    Your browser does not support the audio element.
                </audio>
            </div>
            <div style="float: right;">
                <button class="remove" data-toggle="modal" data-target="#myModal" style="padding: 1px 7px 7px;">
                    <svg class="tcb-icon" viewBox="0 0 448 512" data-id="icon-trash-alt-light" data-name="">
                        <path d="M296 432h16a8 8 0 0 0 8-8V152a8 8 0 0 0-8-8h-16a8 8 0 0 0-8 8v272a8 8 0 0 0 8 8zm-160 0h16a8 8 0 0 0 8-8V152a8 8 0 0 0-8-8h-16a8 8 0 0 0-8 8v272a8 8 0 0 0 8 8zM440 64H336l-33.6-44.8A48 48 0 0 0 264 0h-80a48 48 0 0 0-38.4 19.2L112 64H8a8 8 0 0 0-8 8v16a8 8 0 0 0 8 8h24v368a48 48 0 0 0 48 48h288a48 48 0 0 0 48-48V96h24a8 8 0 0 0 8-8V72a8 8 0 0 0-8-8zM171.2 38.4A16.1 16.1 0 0 1 184 32h80a16.1 16.1 0 0 1 12.8 6.4L296 64H152zM384 464a16 16 0 0 1-16 16H80a16 16 0 0 1-16-16V96h320zm-168-32h16a8 8 0 0 0 8-8V152a8 8 0 0 0-8-8h-16a8 8 0 0 0-8 8v272a8 8 0 0 0 8 8z"></path>
                    </svg>
                </button>
            </div>
        </div>
    </div>
    <div class="row records">

    </div>
</div>
<div id="myModal" class="modal fade">
    <div class="modal-dialog modal-confirm">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Are you sure?</h4>
            </div>
            <div class="modal-body">
                <p>Do you really want to delete this record?</p>
                <p>This process cannot be undone.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-info btn-sm" data-dismiss="modal">CANCEL</button>
                <button type="button" class="btn btn-danger delete-modal btn-sm btn-save" data-id="" data-dismiss="modal">DELETE</button>
            </div>
        </div>
    </div>
</div>
<style type="text/css">
    .modal-confirm {
        color: #636363;
    }
    .modal-confirm .modal-content {
        padding: 5px;
        border-radius: 5px;
        border: none;
        align-items: center;
        text-align: center;
        font-size: 14px;
    }
    .modal-content {
        width: auto !important;
    }
    .modal-confirm .modal-header {
        border-bottom: none;
        position: relative;
    }
    .modal-confirm h4 {
        text-align: center;
        font-size: 26px;
        margin: 5px 0 -10px -10px;
    }
    .modal-confirm .close {
        position: absolute;
        top: -5px;
        right: -2px;
    }
    .modal-confirm .modal-body {
        color: #333333;
    }
    .modal-confirm .modal-footer {
        border: none;
        text-align: center;
        border-radius: 5px;
        font-size: 13px;
        padding: 10px 15px 25px;
    }
    .modal-confirm .modal-footer a {
        color: #999;
    }
    .modal-confirm .icon-box {
        width: 80px;
        height: 80px;
        margin: 0 auto;
        border-radius: 50%;
        z-index: 9;
        text-align: center;
        border: 3px solid #f15e5e;
    }
    .modal-confirm .icon-box i {
        color: #f15e5e;
        font-size: 46px;
        display: inline-block;
        margin-top: 13px;
    }
    .modal-confirm .btn {
        color: #fff;
        border-radius: 4px;
        background: #60c7c1;
        text-decoration: none;
        transition: all 0.4s;
        line-height: normal;
        min-width: 80px;
        border: none;
        min-height: 40px;
        border-radius: 3px;
        margin: 0 5px;
        outline: none !important;
    }
    .modal-confirm .btn-info {
        background: #c1c1c1;
    }
    .modal-confirm .btn-info:hover, .modal-confirm .btn-info:focus {
        background: #a8a8a8;
    }
    .modal-confirm .btn-danger {
        background: #f15e5e;
    }
    .modal-confirm .btn-danger:hover, .modal-confirm .btn-danger:focus {
        background: #ee3535;
    }
    .tcb-icon {
        display: inline-block;
        width: 1.5em;
        height: 1.5em;
        line-height: 1em;
        vertical-align: middle;
        stroke-width: 0;
        stroke: currentColor;
        fill: currentColor;
        -webkit-box-sizing: content-box;
        box-sizing: content-box;
    }
    svg {
        overflow: hidden;
        vertical-align: middle;
    }
    [type=button]:not(:disabled), [type=reset]:not(:disabled), [type=submit]:not(:disabled), button:not(:disabled) {
        cursor: pointer;
    }
    [type=button], [type=reset], [type=submit], button {
        -webkit-appearance: button;
    }
</style>

