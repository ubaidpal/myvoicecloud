(function ($) {
  'use strict';

  $(document).ready(function() {
    var tagEditor = new Tagify($('#tag-editor').get(0));
  });
})(jQuery);
