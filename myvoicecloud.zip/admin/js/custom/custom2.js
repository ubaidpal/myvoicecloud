/*This is our custom js file*/
jQuery(document).ready(function () {
    $('textarea#tiny').tinymce({    });
    jQuery(document).ready(function () {
        var dTable = jQuery('#example_table');
        dTable.DataTable({
            // "ordering": true,
            'order': [[0, 'desc']],
            'aoColumns': [
                null,
                {
                    'bSortable': false
                }
            ]
        });

    });
    jQuery(".cust-plugin-edit").on("click",function(){
        var dataid = jQuery(this).attr("data-id");

        var postdata = "action=submit_request&param=edit_record_data&id=" + dataid;
        jQuery.post(plugin_ajax_url, postdata, function (response) {
            var data = jQuery.parseJSON(response);

            var data = jQuery.parseJSON(response);
            if (data.status == 1) {
                jQuery('#title').val(data.record.title);
                jQuery('#p_id').val(dataid);
                jQuery("#media-image").attr("src", data.record.background);
                jQuery("#image-url").attr("src", data.record.background);
                jQuery('#tiny').text(data.record.transcription);
                jQuery('#speed').val(data.record.speed);
                jQuery('#options').val(data.record.options);
                jQuery('#category_tag').val(data.record.category_tag);
                jQuery('#audio-url').val(data.record.audio);
                jQuery('#audio_url').val(data.record.audio);
               /* if(data.record.active != null){
                    jQuery('#active').prop('checked',true);
                }*/
                var elementId = data.record.export_format;
              $("#export_format").val(jQuery('#' + elementId).val());
            /*   $('#export_format option').filter(function(){
                   if('mp3' == data.record.export_format){
                       return this.id === elementId
                   }

                }).prop('selected', true);*/


                //    jQuery("#boiler-table-playlist").html(data.template);
                //alert(data.message);

            }
        });
    });
    jQuery("#frmUpdateProduct").validate({ // save product
        submitHandler: function () {
            // go and save this info
            var postdata = jQuery("#frmUpdateProduct").serialize() + "&action=submit_request&param=update_playlist";
            jQuery.post(plugin_ajax_url, postdata, function (response) {
                var data = jQuery.parseJSON(response);
                //data.status
                //data.message
                if (data.status == 1) {
                    alert(data.message);
                } else {
                    alert(data.message);
                }
                location.reload();
            });
        }
    });
    // delete the record
    jQuery(".cust-plugin-delete").on("click", function () {
        var conf = confirm("Are you sure want to delete?");
        if (conf) { // true
            var dataid = jQuery(this).attr("data-id");
            var postdata = "action=submit_request&param=delete_record_data&id=" + dataid;
            jQuery.post(plugin_ajax_url, postdata, function (response) {
                var data = jQuery.parseJSON(response);
                if (data.status == 1) {
                //    jQuery("#boiler-table-playlist").html(data.template);
                    //alert(data.message);
                   setTimeout(function () {
                        location.reload();
                    }, 1000);
                }else{
                    alert(data.msg);
                }
            });
        }
    });

    jQuery("#frmAddProduct").validate({ // save product
        submitHandler: function () {
            // go and save this info
            var postdata = jQuery("#frmAddProduct").serialize() + "&action=submit_request&param=save_playlist";
            jQuery.post(plugin_ajax_url, postdata, function (response) {
                var data = jQuery.parseJSON(response);
                //data.status
                //data.message
                if (data.status == 1) {
                    alert(data.message);
                } else {
                    alert(data.message);
                }
                location.reload();
            });
        }
    });

    jQuery("#media-upload").on("click", function () {
        var image = wp.media({
            title: "Upload Your Audio Image",
            multiple: false
        }).open().on("select", function () {
            var files = image.state().get("selection").first();
            //var files = image.state().get("selection");
            var jsonFiles = files.toJSON();
            jQuery("#media-image").attr("src", jsonFiles.url);
            jQuery("#image-url").val(jsonFiles.url);
            //console.log(jsonFiles);
            /*jQuery.each(jsonFiles,function(index,item){
             console.log(item.title+" , "+item.url);
             });*/
        });
    });

    jQuery("#audio-upload").on("click", function () {
        var image = wp.media({
            title: "Upload Your Audio File",
            multiple: false
        }).open().on("select", function () {
            var files = image.state().get("selection").first();
            //var files = image.state().get("selection");
            var jsonFiles = files.toJSON();
            jQuery("#audio-image").attr("src", jsonFiles.url);
            jQuery("#audio-url").val(jsonFiles.url);
            //console.log(jsonFiles);
            /*jQuery.each(jsonFiles,function(index,item){
             console.log(item.title+" , "+item.url);
             });*/
        });
    });

    jQuery("#frmAddClientCredential").validate({ // save client
        submitHandler: function () {
            // go and save this info
            var postdata = jQuery("#frmAddClientCredential").serialize() + "&action=submit_credential_request&param=save_credential";
            jQuery.post(plugin_ajax_url, postdata, function (response) {
                var data = jQuery.parseJSON(response);
                //data.status
                //data.message
                if (data.status == 1) {
                    alert(data.message);
                } else {
                    alert(data.message);
                }
                location.reload();
            });
        }
    });
    jQuery("#client-image-upload").on("click", function () {
        var image = wp.media({
            title: "Upload Client Image",
            multiple: false
        }).open().on("select", function () {
            var files = image.state().get("selection").first();
            //var files = image.state().get("selection");
            var jsonFiles = files.toJSON();
            jQuery("#client-media-image").attr("src", jsonFiles.url);
            jQuery("#client-image-url").val(jsonFiles.url);

        });
    });

});
