<?php

if (!empty($all_products)) {

    $i = 1;
    foreach ($all_products as $index => $data) {
        ?>
        <tr>
            <td><?php echo $i++; ?></td>
            <td><?php echo @$data['created_at'] ?></td>
            <td><?php echo @$data['title'] ?></td>
            <td><img src="<?php echo @$data['background']; ?>" style="height: 50px;width:50px"/></td>
            <td><?php echo  wp_trim_words( @$data['transcription'],   15, $more = null ); ?></td>
            <td><?php echo @$data['speed']; ?></td>
            <td><?php echo @$data['options']; ?></td>
            <td><?php echo @$data['category_tag']; ?></td>
            <td><?php echo @$data['client_id']; ?></td>
            <td><?php echo @$data['export_format']; ?></td>
            <td>
            <a href="javascipt:void(0)" class="btn btn-info cust-plugin-edit" data-toggle="modal" data-id="<?php echo $data['id']; ?>" data-target="#boiler-edit-modal">Edit</a>
            <!--    <a href="javascipt:void(0)" class="btn btn-info cust-plugin-edit" data-id="<?php /*echo $data['id']; */?>" >Edit</a>-->
                <a href="javascipt:void(0)" class="btn btn-danger cust-plugin-delete" data-id="<?php echo $data['id']; ?>">Delete</a>
            </td>
        </tr>
        <?php
    }
} else {
    echo "<h4>No Playlist found</h4>";
}
?>

