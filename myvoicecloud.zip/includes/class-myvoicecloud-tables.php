<?php
class Myvoicecloud_Tables {
    public function wp_audio_categories() {
        globaL $wpdb;
        return $wpdb->prefix = 'wp_audio_categories';
    }

    public function wp_audio_products() {
        globaL $wpdb;
        return $wpdb->prefix = 'wp_audio_products';
    }

    public function wp_audio_clients() {
        globaL $wpdb;
        return $wpdb->prefix = 'wp_audio_clients';
    }

    public function wp_audio_client_plans() {
        globaL $wpdb;
        return $wpdb->prefix = 'wp_audio_client_plans';
    }
}
