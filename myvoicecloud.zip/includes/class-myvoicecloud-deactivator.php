<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://myvoicecloud.com
 * @since      1.0.0
 *
 * @package    Myvoicecloud
 * @subpackage Myvoicecloud/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Myvoicecloud
 * @subpackage Myvoicecloud/includes
 * @author     Andreas Lengyel <support@myvoicecloud.com>
 */
class Myvoicecloud_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
    public  $table;
    public function __construct($table_var) {
        $this->table = $table_var; // called object at constructor to load table name dynamically
    }
	public function deactivate() {
        flush_rewrite_rules();
        // Drop the table If Exist
      /*  globaL $wpdb;
        $wpdb->query('DROP TABLE IF EXISTS '.$this->table->wp_audio_categories());
        $wpdb->query('DROP TABLE IF EXISTS '.$this->table->wp_audio_products());
        $wpdb->query('DROP TABLE IF EXISTS '.$this->table->wp_audio_clients());
        $wpdb->query('DROP TABLE IF EXISTS '.$this->table->wp_audio_client_plans());*/
	}

}
