<h1 class="content-heading">Pick Audio and Record!</h1>
<h2>Choose the audio you want to record your voice over:</h2>
<div class="content-description"></div>
<div class="row">

   <?php
   if(!empty($products)) {
       foreach ($products as $product) {  ?>
           <div class="col-md-4 col-lg-3 col-sm-6 product-item">
               <a href="admin.php?page=products&p_id=<?php echo @$product['id'] ?>">
                   <div class="image" style=" height: 200px;">
                       <img style=" max-height: 100%; max-width: 100%;" src="<?php echo @$product['background'] ?>"/>
                   </div>
                   <div class="title" style="padding-left: 5px; padding-top: 10px">
                       <h3><?php echo @$product['title'] ?></h3>
                   </div>
                   <div class="" style="padding-left: 5px; padding-top: 10px">
                       <span><i>Excerpt from the transcript: </i><?php echo  substr(@$product['transcription'], 0, 100) . '...' ?></span>
                   </div>
               </a>

               <div class="" style="padding-left: 5px; padding-top: 10px">
                   <h5>Listen to audio excerpt</h5>
                   <audio controlsList="nodownload" controls="" style="width: 100%;" playsinline="">
                       <source src="<?php echo @$product['audio'] ?>" type="audio/mpeg">
                   </audio>
               </div>
               <div class="" style="padding-left: 5px; padding-top: 10px">
                   <a href="admin.php?page=products&p_id=<?php echo @$product['id'] ?>" class="button">
                       CLICK TO RECORD
                   </a>
               </div>
           </div>

   <?php
       }
   }
   ?>
</div>
