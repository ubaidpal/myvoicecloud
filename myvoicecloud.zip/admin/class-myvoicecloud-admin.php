<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://myvoicecloud.com
 * @since      1.0.0
 *
 * @package    Myvoicecloud
 * @subpackage Myvoicecloud/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Myvoicecloud
 * @subpackage Myvoicecloud/admin
 * @author     Andreas Lengyel <support@myvoicecloud.com>
 */
class Myvoicecloud_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Myvoicecloud_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Myvoicecloud_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

      //  wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/myvoicecloud-admin.css', array(), $this->version, 'all');
        wp_enqueue_style('f-style.min.css', plugin_dir_url(__FILE__) . 'fonts/open-sans/f-style.min.css', array());
        wp_enqueue_style('iconfont.css', plugin_dir_url(__FILE__) . 'fonts/iconfont/iconfont.css', array());
        wp_enqueue_style('flatpickr.min.css', plugin_dir_url(__FILE__) . 'vendor/flatpickr/flatpickr.min.css', array());
        wp_enqueue_style('select2.min.css', plugin_dir_url(__FILE__) . 'vendor/select2/css/select2.min.css', array());
        wp_enqueue_style('bootstrap.min.css', plugin_dir_url(__FILE__) . 'vendor/bootstrap/css/bootstrap.min.css', array());
        wp_enqueue_style('style.css', plugin_dir_url(__FILE__) . 'css/style.css', array());
        wp_enqueue_style('custom.css', plugin_dir_url(__FILE__) . 'css/custom.css', array());

        wp_enqueue_style("bootstrap.min.css", plugin_dir_url(__FILE__) . 'css/custom/bootstrap.min.css', array(), $this->version, 'all');
        wp_enqueue_style("datatables.min.css", plugin_dir_url(__FILE__) . 'css/custom/jquery.dataTables.min.css', array(), $this->version, 'all');
        wp_enqueue_style("custom2.css", plugin_dir_url(__FILE__) . 'css/custom/custom2.css', array(), $this->version, 'all');

   //     wp_enqueue_style('font-awesome.min.css', plugin_dir_url(__FILE__) . 'css/font-awesome.min.css', array());

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Myvoicecloud_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Myvoicecloud_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */


		wp_enqueue_script('ie.assign.fix.js', plugin_dir_url( __FILE__ ) . 'js/ie.assign.fix.js', array( 'jquery' ), $this->version, true );
		wp_enqueue_script( 'echarts.min.js', plugin_dir_url( __FILE__ ) . 'vendor/echarts/echarts.min.js', array( 'jquery' ), $this->version, true );
		wp_enqueue_script( 'jquery.min.js', plugin_dir_url( __FILE__ ) . 'vendor/jquery/jquery.min.js', array( 'jquery' ), $this->version, true );
		wp_enqueue_script( 'popper.min.js', plugin_dir_url( __FILE__ ) . 'vendor/popper/popper.min.js', array( 'jquery' ), $this->version, true );
		wp_enqueue_script( 'bootstrap.min.js', plugin_dir_url( __FILE__ ) . 'vendor/bootstrap/js/bootstrap.min.js', array( 'jquery' ), $this->version, true );
		wp_enqueue_script( 'select2.full.min.js', plugin_dir_url( __FILE__ ) . 'vendor/select2/js/select2.full.min.js', array( 'jquery' ), $this->version, true );
		wp_enqueue_script( 'simplebar.js', plugin_dir_url( __FILE__ ) . 'vendor/simplebar/simplebar.js', array( 'jquery' ), $this->version, true );
		wp_enqueue_script( 'jquery.textavatar.js', plugin_dir_url( __FILE__ ) . 'vendor/text-avatar/jquery.textavatar.js', array( 'jquery' ), $this->version, true );
		wp_enqueue_script( 'flatpickr.min.js', plugin_dir_url( __FILE__ ) . 'vendor/flatpickr/flatpickr.min.js', array( 'jquery' ), $this->version, true );
		wp_enqueue_script( 'wNumb.js', plugin_dir_url( __FILE__ ) . 'vendor/wnumb/wNumb.js', array( 'jquery' ), $this->version, true );
		wp_enqueue_script( 'main.js', plugin_dir_url( __FILE__ ) . 'js/main.js', array( 'jquery' ), $this->version, true );

		wp_enqueue_script( 'jquery.sparkline.min.js', plugin_dir_url( __FILE__ ) . 'vendor/sparkline/jquery.sparkline.min.js', array( 'jquery' ), $this->version, true );
		wp_enqueue_script('default-dashboard.min.js', plugin_dir_url( __FILE__ ) . 'js/preview/default-dashboard.min.js', array( 'jquery' ), $this->version, true );
	//	wp_enqueue_script('jquery-min.js', plugin_dir_url( __FILE__ ) . 'js/jquery-min.js', array( 'jquery' ), $this->version, true );
	//	wp_enqueue_script('jquery.marquee.min.js', plugin_dir_url( __FILE__ ) . 'js/jquery.marquee.min.js', array( 'jquery' ), $this->version, true );
		wp_enqueue_script('p5.min.js', plugin_dir_url( __FILE__ ) . 'js/p5.min.js', array( 'jquery' ), $this->version, true );
       // wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/myvoicecloud-admin.js', array( 'jquery' ), $this->version, true );
        wp_enqueue_script( 'myvoicecloud-admin.js', plugin_dir_url( __FILE__ ) . 'js/myvoicecloud-admin.js', array( 'jquery' ), $this->version, true );



        wp_enqueue_script("bootstrap.min.js", plugin_dir_url(__FILE__) . 'js/custom/bootstrap.min.js', array('jquery'), $this->version, true);
        wp_enqueue_script("datatables.js", plugin_dir_url(__FILE__) . 'js/custom/jquery.dataTables.min.js', array('jquery'), $this->version, true);
        wp_enqueue_script("notifyBar.js", plugin_dir_url(__FILE__) . 'js/custom/jquery.notifyBar.js', array('jquery'), $this->version, true);
        wp_enqueue_script("validate.min.js", plugin_dir_url(__FILE__) . 'js/custom/jquery.validate.min.js', array('jquery'), $this->version, true);
        wp_enqueue_script("tinymce.min.js", plugin_dir_url(__FILE__) . 'js/custom/tinymce.min.js', array('jquery'), $this->version, true);
        wp_enqueue_script("jquery.tinymce.min.js", plugin_dir_url(__FILE__) . 'js/custom/jquery.tinymce.min.js', array('jquery'), $this->version, true);
        wp_enqueue_script("custom2.js", plugin_dir_url(__FILE__) . 'js/custom/custom2.js', array('jquery'), $this->version, true);
        wp_localize_script("custom2.js", "plugin_ajax_url", admin_url("admin-ajax.php"));


	}
    /**
     * Register the show plugin menu.
     *
     * @since    1.0.0
     */
    public function my_voice_recorder_menu() {
        add_menu_page('My Voice Cloud' , 'My Voice Cloud' , 'manage_options' , 'dashboard' , '' , 'dashicons-playlist-audio' , 53);
        add_submenu_page('dashboard' , 'Pick Audio Record' , 'Dashboard' , 'manage_options' , 'dashboard' ,array($this,'my_voice_menu_record'));
        add_submenu_page('dashboard' , 'Pick Audio Record' , 'Recordings' , 'manage_options' , 'products' ,array($this,'my_voice_menu_recordings_list'));
        add_submenu_page('dashboard' , 'My recordings' , 'My Recordings' , 'manage_options' , 'submenu-recordings' ,array($this,'my_voice_menu_Recordings'));

        add_submenu_page('dashboard' , 'Products' , 'Products' , 'manage_options' , 'submenu-products' ,array($this,'my_voice_menu_Products'));

        add_submenu_page('dashboard' , 'Add Products' , 'Add Products' , 'manage_options' , 'submenu-add-products' ,array($this,'my_voice_add_Products'));
        add_submenu_page('dashboard' , 'Add Client Credential' , 'Add Client Credential' , 'manage_options' , 'submenu-add-client_credential' ,array($this,'my_voice_add_client_credential'));
	}

    public function my_voice_menu_record() {
        if ( ! function_exists( 'wp_get_current_user' ) ) {
            return 0;
        }
        $user = wp_get_current_user();
        $user_id = ( isset( $user->ID ) ? (int) $user->ID : 0 );
        globaL $wpdb;
        require_once VOICE_CLOUD_PLUGIN_DIR . 'includes/class-myvoicecloud-tables.php';
        $tables = new Myvoicecloud_Tables();
        $p = $wpdb->get_results(
                                    $wpdb->prepare(
                                        //"Select * From " . $tables->wp_audio_products() . " WHERE client_id = ".$user_id." ORDER BY id DESC", ""
                                        "Select * From " . $tables->wp_audio_products() . " ORDER BY id DESC", ""
                                    ), ARRAY_A
                            );
        if(!empty($p)){
            $products = $p;
        }else{
            $products =
              array(
                  0   =>     [
                      'id'            => 1,
                      'created_at'    => '2021-03-31 12:35:25',
                      'updated_at'    => '2021-03-31 12:35:25',
                      'title'         => 'twinkle',
                      'audio'         => 'https://media.wordpress.site/wp-content/uploads/2021/04/Offsetclean.wav',
                      'background'    => 'https://media.wordpress.site/wp-content/uploads/2021/04/EoSjAPbBrkdC7EPD6uvw.jpg',
                      'transcription' => '<p>Twinkle Twinke Little Star</p>',
                      'speed'         => 15,
                      'options'       => 1,
                      'category_tag'  => 'Sku',
                      'client_id'     => 1,
                      'export_format' => 'wav'
                             ]

              );
        }



        include_once VOICE_CLOUD_PLUGIN_DIR . '/admin/partials/header/myvoicecloud-admin-header-display.php';

        include_once VOICE_CLOUD_PLUGIN_DIR . '/admin/partials/myvoicecloud-admin-dashboard-display.php';

        include_once VOICE_CLOUD_PLUGIN_DIR . '/admin/partials/footer/myvoicecloud-admin-footer-display.php';

    }

    public function my_voice_menu_recordings_list() {

        $p_id = isset($_REQUEST['p_id']) ? $_REQUEST['p_id'] : "";
        globaL $wpdb;
        require_once VOICE_CLOUD_PLUGIN_DIR . 'includes/class-myvoicecloud-tables.php';
        $tables = new Myvoicecloud_Tables();
        $p = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * from " . $tables->wp_audio_products() . " WHERE id = %d", $p_id
            ), ARRAY_A

        );

        if(!empty($p)){

            $products = $p;
        }else{
            $products[0] =
                [
                    'id'            => 1,
                    'created_at'    => '2021-03-31 12:35:25',
                    'updated_at'    => '2021-03-31 12:35:25',
                    'title'         => 'twinkle',
                    'background'    => 'EoSjAPbBrkdC7EPD6uvw.jpg',
                    'transcription' => 50000,
                    'speed'         => 41000,
                    'options'       => 'uu',
                    'category_tag'  => 'twinkle',
                    'client_id'     => 1,
                    'export_format' => 'wav'
                ];
        }
//echo '<pre>'; print_r($products); wp_die();

        include_once VOICE_CLOUD_PLUGIN_DIR . '/admin/partials/header/myvoicecloud-admin-header-display.php';

        include_once VOICE_CLOUD_PLUGIN_DIR . '/admin/partials/myvoicecloud-admin-recordings-display.php';

        include_once VOICE_CLOUD_PLUGIN_DIR . '/admin/partials/footer/myvoicecloud-admin-footer-display.php';
    }

    public function my_voice_menu_Recordings() {
        include_once VOICE_CLOUD_PLUGIN_DIR . '/admin/partials/header/myvoicecloud-admin-header-display.php';

        include_once VOICE_CLOUD_PLUGIN_DIR . '/admin/partials/myvoicecloud-admin-display.php';

        include_once VOICE_CLOUD_PLUGIN_DIR . '/admin/partials/footer/myvoicecloud-admin-footer-display.php';
    }

    public function my_voice_menu_Products() {
        global $wpdb;
        require_once VOICE_CLOUD_PLUGIN_DIR . 'includes/class-myvoicecloud-tables.php';
        $tables = new Myvoicecloud_Tables();
       $all_products = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * from " . $tables->wp_audio_products() . " Order by id desc", ""
            ), ARRAY_A
        );
     /*  $placeholder  = '%%%1$s%%';
        $q            = 'SELECT * from ' . $tables->wp_audio_products() . ' Order by id desc';
        $all_products = $wpdb->get_results(
            $wpdb->prepare($q, $placeholder), ARRAY_A
        );*/

        include_once VOICE_CLOUD_PLUGIN_DIR . '/admin/partials/forms/myvoicecloud-menu-all-product.php';
    }
    public function my_voice_add_Products() {
        include_once VOICE_CLOUD_PLUGIN_DIR . '/admin/partials/forms/myvoicecloud-menu-add-product.php';
    }

    public function my_voice_add_client_credential() {
        include_once VOICE_CLOUD_PLUGIN_DIR . '/admin/partials/forms/myvoicecloud-menu-add-client_credential.php';
    }

    public function add_product_ajax_handler() {
        if ( ! function_exists( 'wp_get_current_user' ) ) {
            return 0;
        }
        $user = wp_get_current_user();
        $user_id = ( isset( $user->ID ) ? (int) $user->ID : 0 );
        require_once VOICE_CLOUD_PLUGIN_DIR . 'includes/class-myvoicecloud-tables.php';
        $tables = new Myvoicecloud_Tables();

        $param = isset($_REQUEST['param']) ? $_REQUEST['param'] : "";
        global $wpdb;
       // echo '<pre>'; print_r($_REQUEST);
      //  wp_die();
        if (!empty($param) && $param == "save_playlist") {

            $title         = isset($_REQUEST[ 'title' ]) ? $_REQUEST[ 'title' ] : "";
            $image_url     = isset($_REQUEST[ 'image_url' ]) ? $_REQUEST[ 'image_url' ] : "";
            $transcription = isset($_REQUEST[ 'transcription' ]) ? $_REQUEST[ 'transcription' ] : "";
            $speed         = isset($_REQUEST[ 'speed' ]) ? $_REQUEST[ 'speed' ] : "";
            $options       = isset($_REQUEST[ 'options' ]) ? $_REQUEST[ 'options' ] : "";
            $category_tag  = isset($_REQUEST[ 'category_tag' ]) ? $_REQUEST[ 'category_tag' ] : "";
            $audio_url     = isset($_REQUEST[ 'audio_url' ]) ? $_REQUEST[ 'audio_url' ] : "";
            $export_format = isset($_REQUEST[ 'export_format' ]) ? $_REQUEST[ 'export_format' ] : "";

            // levels contains array value json_encode, serialize
            $wpdb->insert($tables->wp_audio_products(), array(
                "created_at"    => date('Y-m-d H:i:s'),
                "updated_at"    => date('Y-m-d H:i:s'),
                "title"         => $title,
                "audio"         => $audio_url,
                "background"    => $image_url,
                "transcription" => $transcription,
                "speed"         => $speed,
                "options"       => $options,
                "category_tag"  => $category_tag,
                "client_id"     => $user_id, // user id
                "export_format" => $export_format

            ));
            if ($wpdb->insert_id > 0) {
                echo json_encode(array(
                    "status" => 1,
                    "message" => "Value has been inserted"
                ));
            } else {
                echo json_encode(array(
                    "status" => 0,
                    "message" => "Failed to insert"
                ));
            }
            //$this->tables->owtboliertable();
        } elseif (!empty($param) && $param == "delete_record_data") {
            $data_id = isset($_REQUEST['id']) ? intval($_REQUEST['id']) : 0;
            $is_exists = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT * from " . $tables->wp_audio_products() . " WHERE id = %d", $data_id
                ), ARRAY_A
            );
            if (!empty($is_exists)) {
                $wpdb->delete($tables->wp_audio_products(), array(
                    "id" => $data_id
                ));
                ob_start(); //start
                include_once VOICE_CLOUD_PLUGIN_DIR . "/admin/partials/forms/tmpl/plugin-tmpl-playlists.php";
                $template = ob_get_contents();
                ob_end_clean(); //end
                echo json_encode(array("status" => 1, "message" => "Record has deleted", "template" => $template));
            } else {
                echo json_encode(array("status" => 0, "message" => "No record found"));
            }
        }elseif (!empty($param) && $param == "edit_record_data") {

            $data_id = isset($_REQUEST['id']) ? intval($_REQUEST['id']) : 0;

            $is_exists = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT * from " . $tables->wp_audio_products() . " WHERE id = %d", $data_id
                ), ARRAY_A
            );
            if (!empty($is_exists)) {
                echo json_encode(array("status" => 1, "record" => $is_exists));
            }
        }else if (!empty($param) && $param == "update_playlist") {

            $data_id = isset($_REQUEST['p_id']) ? intval($_REQUEST['p_id']) : 0;
            $title         = isset($_REQUEST[ 'title' ]) ? $_REQUEST[ 'title' ] : "";
            $image_url     = isset($_REQUEST[ 'image_url' ]) ? $_REQUEST[ 'image_url' ] : "";
            $transcription = isset($_REQUEST[ 'transcription' ]) ? $_REQUEST[ 'transcription' ] : "";
            $speed         = isset($_REQUEST[ 'speed' ]) ? $_REQUEST[ 'speed' ] : "";
            $options       = isset($_REQUEST[ 'options' ]) ? $_REQUEST[ 'options' ] : "";
            $category_tag  = isset($_REQUEST[ 'category_tag' ]) ? $_REQUEST[ 'category_tag' ] : "";
            $audio_url     = isset($_REQUEST[ 'audio_url' ]) ? $_REQUEST[ 'audio_url' ] : "";
            $export_format = isset($_REQUEST[ 'export_format' ]) ? $_REQUEST[ 'export_format' ] : "";

            $wpdb->update($tables->wp_audio_products(), array(
             //   "created_at"    => date('Y-m-d H:i:s'),
                "updated_at"    => date('Y-m-d H:i:s'),
                "title"         => $title,
                "audio"         => $audio_url,
                "background"    => $image_url,
                "transcription" => $transcription,
                "speed"         => $speed,
                "options"       => $options,
                "category_tag"  => $category_tag,
                "client_id"     => $user_id, // user id
                "export_format" => $export_format

            ), array('ID' => $data_id));
            // levels contains array value json_encode, serialize

            echo json_encode(array(
                "status" => 1,
                "message" => "Value has been updated"
            ));
            //$this->tables->owtboliertable();
        }
        wp_die();
    }

    public function add_credential_ajax_handler() {

        if ( ! function_exists( 'wp_get_current_user' ) ) {
            return 0;
        }
        $user = wp_get_current_user();
        $user_id = ( isset( $user->ID ) ? (int) $user->ID : 0 );
        require_once VOICE_CLOUD_PLUGIN_DIR . 'includes/class-myvoicecloud-tables.php';
        $tables = new Myvoicecloud_Tables();

        $param = isset($_REQUEST['param']) ? $_REQUEST['param'] : "";
        global $wpdb;
        // echo '<pre>'; print_r($_REQUEST);
        //  wp_die();
        if (!empty($param) && $param == "save_credential") {

            $name      = isset($_REQUEST[ 'name' ]) ? $_REQUEST[ 'name' ] : "";
            $image_url = isset($_REQUEST[ 'image_url' ]) ? $_REQUEST[ 'image_url' ] : "";
            $subdomain = isset($_REQUEST[ 'subdomain' ]) ? $_REQUEST[ 'subdomain' ] : "";

            // levels contains array value json_encode, serialize
            $wpdb->insert($tables->wp_audio_clients(), array(
                "subdomain"  => $subdomain,
                "image"      => $image_url,
                "created_at" => date('Y-m-d H:i:s'),
                "updated_at" => date('Y-m-d H:i:s'),
                "name"       => $name,


            ));
            if ($wpdb->insert_id > 0) {
                echo json_encode(array(
                    "status" => 1,
                    "message" => "Value has been inserted"
                ));
            } else {
                echo json_encode(array(
                    "status" => 0,
                    "message" => "Failed to insert"
                ));
            }
            //$this->tables->owtboliertable();
        } elseif (!empty($param) && $param == "delete_record_data") {
            $data_id = isset($_REQUEST['id']) ? intval($_REQUEST['id']) : 0;
            $is_exists = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT * from " . $tables->wp_audio_clients() . " WHERE id = %d", $data_id
                ), ARRAY_A
            );
            if (!empty($is_exists)) {
                $wpdb->delete($tables->wp_audio_clients(), array(
                    "id" => $data_id
                ));
                ob_start(); //start
                include_once VOICE_CLOUD_PLUGIN_DIR . "/admin/partials/forms/tmpl/plugin-tmpl-playlists.php";
                $template = ob_get_contents();
                ob_end_clean(); //end
                echo json_encode(array("status" => 1, "message" => "Record has deleted", "template" => $template));
            } else {
                echo json_encode(array("status" => 0, "message" => "No record found"));
            }
        }
        wp_die();
    }
}
